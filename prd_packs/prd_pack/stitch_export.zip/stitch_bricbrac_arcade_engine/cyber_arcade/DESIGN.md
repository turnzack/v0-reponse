---
name: Cyber-Arcade
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dbe7'
  primary: '#e1fdff'
  on-primary: '#00363a'
  primary-container: '#00f2ff'
  on-primary-container: '#006a71'
  inverse-primary: '#00696f'
  secondary: '#fface8'
  on-secondary: '#5e0053'
  secondary-container: '#ff24e4'
  on-secondary-container: '#520049'
  tertiary: '#e4ffd6'
  on-tertiary: '#053900'
  tertiary-container: '#34fc0d'
  on-tertiary-container: '#106f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#74f5ff'
  primary-fixed-dim: '#00dbe7'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#ffd7f0'
  secondary-fixed-dim: '#fface8'
  on-secondary-fixed: '#3a0033'
  on-secondary-fixed-variant: '#840076'
  tertiary-fixed: '#79ff5b'
  tertiary-fixed-dim: '#2ae500'
  on-tertiary-fixed: '#022100'
  on-tertiary-fixed-variant: '#095300'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.02em
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  score-md:
    fontFamily: Space Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0.1em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.15em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
  panel-padding: 24px
---

## Brand & Style
The design system is a high-octane "Cyber-Arcade" aesthetic tailored for BRICBRAC. It merges 80s synthwave nostalgia with high-fidelity modern UI precision. The interface must feel like a high-end physical arcade cabinet from a futuristic dystopia—pulsating with energy, tactile, and immersive.

**Core Principles:**
- **Kinetic Energy:** Every interaction should feel like it's powered by high-voltage electricity.
- **Neon-Depth:** Use light as a structural element. Borders are not just lines; they are light sources.
- **HUD Precision:** Information should be presented with the clarity of a fighter jet's Head-Up Display (HUD), ensuring readability amidst the chaotic action of a brick-breaker game.
- **Modern Retro:** Avoid "crusty" retro tropes. Maintain crisp edges, high-resolution blurs, and sophisticated typography.

## Colors
The palette is built on a "Deep Midnight" foundation to maximize the perceived luminance of the neon accents.

- **Primary (Electric Cyan):** Used for critical gameplay UI, player stats, and primary action buttons.
- **Secondary (Hot Pink):** Used for power-ups, high scores, and destructive elements.
- **Tertiary (Acid Green):** Used for success states, health bars, and "Ready" indicators.
- **Neutrals:** The background is near-black (#050505). Surfaces use a slightly elevated #0A0A0F with 80% opacity to allow background textures (like scanlines) to bleed through.

**Glow Strategy:**
All neon colors must be accompanied by a color-matched outer glow (box-shadow or drop-shadow). For standard UI elements, use a 5px to 10px blur. For "active" or "charged" states, increase the blur to 20px.

## Typography
The typographic hierarchy contrasts high-tech utility with aggressive geometric headlines.

- **Headlines:** Space Grotesk provides a futuristic, wide-set look that feels engineered.
- **UI & Body:** Geist is used for its clinical, developer-centric legibility, ensuring stats and settings are easy to parse.
- **Data & Scores:** Space Mono is used for all numerical data and labels to evoke a retro-terminal or hardware-readout feel.

**Styling Note:** Headlines should often be italicized (oblique) to imply speed and motion. Text shadows in Electric Cyan should be applied to high-level headers to mimic "light-leak" effects.

## Layout & Spacing
The layout uses a **Fluid HUD Grid**. Unlike traditional websites, this system prioritizes a central "Play Field" with peripheral "Data Clusters."

- **The HUD Model:** Components are anchored to the corners of the viewport (Safe Zones) to keep the center clear for gameplay.
- **Grid:** Use an 8-pixel rhythm for all spacing. 
- **Scanline Overlay:** A global fixed-position overlay with a repeating linear-gradient (transparent to black at 2px intervals) should be applied at 5% opacity to provide texture.
- **Breakpoints:**
  - **Mobile (<768px):** Single column HUD, stacked at the bottom and top edges.
  - **Desktop (>768px):** Lateral panels for stats (left) and inventory/power-ups (right).

## Elevation & Depth
Depth in this design system is achieved through **Luminance Layering** and **Backdrop Blurs**.

1.  **Level 0 (Background):** Solid #050505 with a subtle radial gradient of Hot Pink in the corners.
2.  **Level 1 (Panels):** Semi-transparent #0A0A0F (80% opacity) with a `backdrop-filter: blur(12px)`.
3.  **Level 2 (Borders):** 1px solid strokes of Electric Cyan or Hot Pink. These "wireframes" define the edges of panels.
4.  **Level 3 (Glows):** Elements at this level use `box-shadow` to cast light onto the levels below.

There are no traditional shadows. Instead, think of "Reverse Shadows" (Outer Glows) where the light defines the elevation. Higher-priority items have a wider, more intense glow radius.

## Shapes
The design system utilizes **Sharp (0px)** geometry. Every element should feel like it was cut from glass or etched into a circuit board.

- **Angled Corners:** Use `clip-path` to create 45-degree chamfered corners on buttons and large panels to reinforce the "military-tech" or "arcade" feel.
- **Stroke Weights:** Use consistent 1px strokes for inactive borders and 2px strokes for active/hovered elements.

## Components

**Buttons:**
- **Default:** Transparent background, 1px Cyan border, Space Mono (All Caps) text.
- **Hover:** Solid Cyan background, black text, 15px Cyan outer glow.
- **Active:** Scale down slightly (98%) with a momentary white flash overlay.

**HUD Chips:**
- Small rectangular containers for "Multipliers" or "Level Progress." Use a 1px Hot Pink border and a subtle pink "inner-glow" (box-shadow inset) to make the container look like it's filled with gas.

**Input Fields:**
- Minimalist underlines rather than full boxes. When focused, the underline should pulse with a Cyan glow.

**Cards / Panels:**
- Use the chamfered corner style. Top-left corner should feature a small "Tech Label" (e.g., "SYSTEM_v1.0") in 8px Space Mono.

**Progress Bars:**
- Segmented bars (e.g., 10 individual blocks) rather than a solid fill. Each block lights up with Acid Green as it fills.

**Interaction States:**
- All interactive elements must have a "Scanline Flicker" animation on hover—a brief, rapid change in opacity to simulate a CRT screen reacting to input.